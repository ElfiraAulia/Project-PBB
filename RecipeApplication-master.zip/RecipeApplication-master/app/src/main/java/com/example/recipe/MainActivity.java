package com.example.recipe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView myrecyclerView;
    RecyclerViewAdapter myAdapter;

    List<Recipes> recipes1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recipes1 = new ArrayList<>();
        recipes1.add(new Recipes("PAPEDA","9 sdm tepung tapioka \n" +
                "1 sdm tepung terigu \n" +
                "250 ml air \n" +
                "garam dan kaldu bubuk secukupnya \n" +
                "1 butir telur \n" +
                "garam secukupnya\n" +
                "Bubuk cabe \n" +
                "Abon \n" +
                "Bumbu cimol \n" +
                "Bubuk balado\n","Langkah",
                "1.\tCampurkan semua bahan adonan di mangkuk, aduk rata.\n" +
                        "2.\tDadar telur tipis-tipis di wajan anti lengket dengan api kompor kecil. Tuang adonan aci satu sendok sayur di atas dadar telur. Taburkan bahan taburan di bagian atasnya.\n" +
                        "3.\tSaat adonan sudah agak kering, gulung dadar dengan bantuan tusuk sate atau sumpit. Siap disantap. \n",R.drawable.papeda));

        recipes1.add(new Recipes("PANCAKE","225 gr tepung terigu protein sedang\n" +
                "2 sdt baking powder\n" +
                "1/2 sdt garam\n" +
                "1 sdt gula pasir\n" +
                "2 butir telur ayam yang besar\n" +
                "30 gr mentega tawar, lelehkan\n" +
                "300 ml susu cair\n" +
                "mentega untuk olesan\n"+
                "1 batang kayu manis\n","Langkah","\n" +
                "1.\tCampur tepung terigu dengan baking powder, garam dan gula dalam mangkuk. Aduk rata.\n" +
                "2.\tKocok telur hingga berbuih, tambahkan mentega cair dan susu.\n" +
                "3.\tBuat cerukan dalam tepung, tuangkan campuran telur sedikit demi sedikit sambil aduk dengan kocokan kawat hingga licin.\n" +
                "4.\tDiamkan adonan selama 15 menit.\n" +
                "5.\tPanaskan wajan datar, olesi sedikit mentega.\n" +
                "6.\tTuangkan 1 sendok sayur adonan ke atas wajan. Masak hingga permukaannya berlubang kecil. Balikkan pancake, masak sebentar lalu angkat.\n" +
                "7.\tKerjakan yang sama dengan sisa adonan.\n" +
                "8.\tSajikan pancake hangat dengan Pelengkap sesuai selera.\n",R.drawable.pancake));
        recipes1.add(new Recipes("LUMPIA","Kulit lumpia secukupnya\n" +
                "1/2 kg dada ayam, rebus dan suwir-suwir\n" +
                "1/2 kg tauge\n" +
                "1/2 kg wortel, potong korek api\n" +
                "1/4 kg daun bawang, iris halus\n" +
                "Air kaldu secukupnya\n" +
                "1 sdt kecap ikan\n" +
                "Garam, gula, dan kaldu bubuk secukupnya\n" +
                "Bumbu halus:\n" +
                "10 buah bawang merah\n" +
                "8 buah bawang putih\n" +
                "2 sdt merica\n","Langkah",
                "1.\tTumis bumbu halus sampai harum. Kemudian masukkan ayam suwir dan wortel. Aduk rata kemudian masukkan kecap ikan. Setelah wortel agak layu masukkan air kaldu. Masak hingga air menyusut.\n" +
                        "2.\tMasukkan tauge, irisan daun bawang, garam, gula, dan kaldu bubuk. Tes rasa. Masak hingga kuah mengering. Angkat dan tiriskan.\n" +
                        "3.\tAmbil selembar kulit lumpia, beri isian dan lipat seperti amplop lalu beri putih telur pinggiran lumpia sebagai perekat.\n" +
                        "4.\tGoreng lumpia dengan api sedang hingga kuning kecokelatan. Angkat dan tiriskan.\n" +
                        "5.\tSajikan dengan cabai rawit.\n",R.drawable.lumpia));
        recipes1.add(new Recipes("PECEL","400 gr kacang tanah goreng \n" +
                "5 siung bawang putih, tumis hingga layu \n" +
                "15 buah cabai campur (jumlah dan jenis sesuai selera, tumis hingga layu) \n" +
                "100 gr gula merah, sisir halus \n" +
                "2 sdm air asam \n" +
                "1 ruas jari kencur kupas \n" +
                "4 lembar daun jeruk segar, iris kasar \n" +
                "Garam secukupnya\n" +
                "200 ml air matang panas atau secukupnya (untuk membuat bumbu siap santap)\n","Langkah",
                "1.\tUlek halus kacang tanah bersama bahan lain kecuali air matang panas dan daun jeruk.\n" +
                        "2.\tTambahkan daun jeruk, ulek lagi agar tercampur rata. Simpan di stoples kedap udara dan masukkan kulkas jika ingin jadi stok bumbu. \n" +
                        "3.\tEncerkan bumbu pecel dengan air matang panas jika ingin langsung disantap dengan aneka sayuran.\n",R.drawable.pecel));
        recipes1.add(new Recipes("AYAM GEPREK","Terigu secukupnya\n" +
                "2 potong ayam\n" +
                "Garam secukupnya\n" +
                "Lada secukupnya\n" +
                "10 cabai rawit oranye\n" +
                "4 bawang merah\n" +
                "15 cabai rawit ijo\n" +
                "3 bawang putih\n","Langkah",
                "1.\tCampur ayam yang sudah dicuci dengan terigu lalu goreng dengan minyak panas hingga matang dan krispi.\n" +
                        "2.\tSemua bumbu dihaluskan kemudian siram dengan 3 sendok minyak panas, lalu diaduk. Masukkan ayam krispi yg sudah digoreng ke dalam bumbu. Lalu digeprek hingga bumbu meresap.\n",R.drawable.geprek));
        recipes1.add(new Recipes("NASTAR","4 butir kuning telur\n" +
                "2 butir kuning telur untuk dioles\n" +
                "½ kg mentega atau margarin\n" +
                "½ kg tepung terigu\n" +
                "100 gr gula halus\n" +
                "300 gr selai nanas\n" +
                "1 bungkus vanili\n" +
                "100 gr keju cheddar\n" +
                "50 gr kismis\n" +
                "1 batang kayu manis\n","Langkah",
                "1.\tBuat adonan terlebih dahulu. Siapkan loyang berbentuk persegi panjang dan oles dengan margarin.\n" +
                        "2.\tKocok 4 butir kuning telur, gula halus, dan mentega dengan mixer hingga mengembang.\n" +
                        "3.\tMasukkan keju parut ke dalam adonan. Aduk merata dengan speed mixer rendah.\n" +
                        "4.\tMasukkan tepung terigu dan vanili.\n" +
                        "5.\tAduk hingga membentuk adonan yang bisa dibulatkan.\n" +
                        "6.\tBulatkan kue dengan tanganmu.\n" +
                        "7.\tPipihkan adonan kue, kemudian masukkan selai ke tengah adonan kue. Buat bulatan.\n" +
                        "8.\tPotong kismis dan letakkan sepotong kismis di atas kue.\n" +
                        "9.\tOleskan permukaan kue dengan kuning telur.\n" +
                        "10.\tPastikan oven sudah dipanaskan sebelum memasukkan kue nastar.\n" +
                        "11.\tPanggang kue nastar dalam oven selama 30 menit dengan api atas bawah dan suhu 150 derajat Celcius.\n",R.drawable.nastar));
        recipes1.add(new Recipes("ES KUWUD","3 buah kelapa muda keruk lebar, ambil airnya 1.200 ml \n" +
                "200 gr melon keruk lebar \n" +
                "1 sendok makan selasih rendam air \n" +
                "4 buah jeruk nipis ambil airnya \n" +
                "500 gr es batu \n" +
                "250 gr gula pasir 3 lembar daun pandan diikat \n" +
                "200 ml air\n","Langkah",
                "1.\tBikin sirupnya dahulu, rebus air, gula, dan daun pandan. Gunakan api kompor kecil, rebus hingga mendidih. Sisihkan agar sejuk. \n" +
                        "2.\tRendam biji selasih.\n" +
                        "3.\tKeruk kelapa muda dan melon.\n" +
                        "4.\tTata di gelas, tambahkan es batu dan biji selasih yang sudah mengembang. Siram sirop dan perasan air jeruk nipis. Siap disajikan.\n",R.drawable.kuwut));
        recipes1.add(new Recipes("ES OYEN","2 buah alpukat\n" +
                "1 buah kelapa muda\n" +
                "1 bungkus agar-agar\n" +
                "100 ml sirup vanilla\n" +
                "100 gr biji mutiara\n" +
                "5 sdm susu kental manis\n" +
                "1 L air putih\n" +
                "es batu secukupnya\n","Langkah",
                "1.\tPanaskan air di dalam panci dengan api sedang, lalu masukkan agar-agar dan rebus hingga mendidih. Setelah itu, padatkan dan potong kotak-kotak.\n" +
                        "2.\tRebus juga biji mutiara hingga matang. Angkat, lalu sisihkan.\n" +
                        "3.\tPotong buah alpukat, lalu keruk dagingnya dengan sendok dan sisihkan.\n" +
                        "4.\tPotong kelapa muda, lalu keruk dagingnya menggunakan sendok dan sisihkan.\n" +
                        "5.\tTuang semua bahan ke dalam mangkuk atau gelas. Kemudian, tambahkan sirup vanilla, susu kental manis, dan es batu\n" +
                        "6.\tEs Oyen khas Bandung siap dihidangkan.\n",R.drawable.oyen));



        myrecyclerView = (RecyclerView)findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this,recipes1);

        myrecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        myrecyclerView.setAdapter(myAdapter);



    }

}
